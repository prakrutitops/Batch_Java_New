package com.dao;

import java.util.List;

import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.model.Person;

public class MyDao extends HibernateDaoSupport
{

		public void insertdata(Person p)
		{
			getHibernateTemplate().save(p);
		}
		
		public List<Person>viewdetails()
		{
			return getHibernateTemplate().find("from Person");
		}
		
}
