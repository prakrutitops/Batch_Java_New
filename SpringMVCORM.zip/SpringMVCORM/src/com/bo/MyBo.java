package com.bo;

import java.util.List;

import com.dao.MyDao;
import com.model.Person;

public class MyBo 
{
	MyDao personDao;

	
	
	public MyDao getPersonDao() {
		return personDao;
	}

	public void setPersonDao(MyDao personDao) {
		this.personDao = personDao;
	}

	public void insertdata(Person p)
	{
		
		 personDao.insertdata(p);
	}
	
	public List<Person>viewdetails()
	{
		return personDao.viewdetails();
	}
	
	
	
	
}
