package com.controller;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Address;
import com.model.Person;

public class MainClass 
{
	public static void main(String[] args) 
	{
		
		Session sess =  new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		
		Scanner sc =new Scanner(System.in);
		
		Person p =new Person();
		Address a =new Address();
		
		System.out.println("Enter Your Name");
		p.setPname(sc.next());
		
		System.out.println("Enter Your Address");
		a.setAddress(sc.next());
		
		
		a.setPerson(p);
		sess.save(p);
		sess.save(a);
		tr.commit();
		sess.close();
		
		
	}
}
