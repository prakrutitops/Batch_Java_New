package com.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.connect.Util;
import com.model.Address;
import com.model.Person;

public class MainClass 
{
	public static void main(String[] args) 
	{
		
		Session sess =  new Util().getconnect();
		Transaction tr = sess.beginTransaction();
		
		Scanner sc =new Scanner(System.in);
		
		Person p =new Person();
		Address a =new Address();
		Address a2 =new Address();
		
		System.out.println("Enter Your Name");
		p.setPname(sc.next());
		
		System.out.println("Enter Your Address 1");
		a.setAddress(sc.next());
		
		System.out.println("Enter Your Address 2");
		a2.setAddress(sc.next());
		
		List<Address> list =  new ArrayList<>();
		list.add(a);
		list.add(a2);
		p.setAddress(list);
		sess.save(p);
		sess.save(a);
		sess.save(a2);
		tr.commit();
		sess.close();
		
		
	}
}
